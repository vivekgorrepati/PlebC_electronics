Arduino Analog Smooth
=====================

Arduino library to smoothen jittery analog signals

For more information and a usage example visit my [blog](http://michaelthessel.com/analog-smoothing-library-for-arduino/).
